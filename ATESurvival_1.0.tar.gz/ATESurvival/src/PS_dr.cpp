// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;
using namespace std;


// [[Rcpp::export]]
arma::mat PS_dr(const arma::vec& ID,
                const arma::vec& A,
                const arma::mat& Z,
                const arma::vec& event, 
                const arma::vec& time,
                const arma::vec& beta,
                const arma::vec& PS,
                const arma::vec& n_i,
                const NumericVector& t,
                const arma::mat& A_BS,
                const arma::mat& PS_BS,
                const arma::mat& u_BS,
                const Rcpp::Nullable<Rcpp::NumericVector>& trunc_time_init = R_NilValue, 
                const int& cause = 1,
                const double& level = 0.95){
  
  int n = time.size();
  int ncauses = beta.size();
  
  // implement left-truncation
  arma::vec trunc_time = zeros(n);
  if(trunc_time_init.isNotNull()){
    trunc_time = Rcpp::as<arma::vec>(trunc_time_init);
  }
  
  // identify relevant time points
  arma::uvec event_ind = find((event != 0));
  arma::uvec eval_ind = find((event != 0) && (time <= max(t)));
  
  // dN, Y, S0, Z_bar & omega
  std::vector< arma::vec > dN(ncauses);
  arma::vec Y(event_ind.size());
  std::vector < arma::mat > Z_A1(ncauses);
  std::vector < arma::mat > Z_A0(ncauses);
  std::vector< arma::vec > exp_Zb(ncauses);
  std::vector< arma::vec > exp_Zb_A1(ncauses);
  std::vector< arma::vec > exp_Zb_A0(ncauses); 
  std::vector< arma::vec > S0(ncauses);
  std::vector< arma::vec > Z_bar(ncauses);
  std::vector< double > omega(ncauses);
  std::vector< double > omega_inv(ncauses);
  for(int c=0; c<ncauses; c++){
    dN[c] = ones(event_ind.size()) % ((trunc_time.elem(event_ind) < time.elem(event_ind)) && (event.elem(event_ind) == c+1));
    exp_Zb[c] = exp(A * beta[c]);
    S0[c].set_size(event_ind.size());
    Z_bar[c].set_size(event_ind.size());
    omega[c] = 0.0;
  }
  for(int j=0; j < int(event_ind.size()); j++){
    arma::uvec Y_i = find((trunc_time < time[event_ind[j]]) && (time[event_ind[j]] <= time));
    for(int c=0; c<ncauses; c++){
      S0[c][j] = sum(exp_Zb[c].elem(Y_i)) / double(n);
      Z_bar[c][j] = sum(arma::vec(exp_Zb[c] % A).elem(Y_i)) / (double(n) * S0[c][j]);
      omega[c] += (Z_bar[c][j]/S0[c][j] - Z_bar[c][j]*Z_bar[c][j]) * dN[c][j] / double(n);
    }
    Y[j] = Y_i.size();
  }
  for(int c=0; c<ncauses; c++){
    omega_inv[c] = 1 / omega[c];
  }
  
  // dLambda
  std::vector < arma::mat > dLambda(ncauses);
  for(int c=0; c<ncauses; c++){
    dLambda[c].set_size(n, event_ind.size());
    for(int s=0; s<int(event_ind.size()); s++){
      dLambda[c].col(s) = dN[c][s] * exp(A * beta[c]) / (double(n)*S0[c][s]); 
    }
  }
  
  // S & F
  arma::mat S(n, int(eval_ind.size()+1));
  arma::mat F(n, int(eval_ind.size()+1));
  S.col(0) = ones(n);
  F.col(0) = zeros(n);
  for(int s=1; s <= int(eval_ind.size()); s++){
    arma::vec dLambda_all(n, fill::value(0.0));
    for(int c=0; c<ncauses; c++){
      dLambda_all += dLambda[c].col(s-1);
    }
    S.col(s) = min(ones(n), max(zeros(n), S.col(s-1) % (ones(n) - dLambda_all)));
    arma::vec dF(n, fill::value(0.0));
    if(dN[cause-1][s-1] > 0){
      dF = S.col(s-1) % dLambda[cause-1].col(s-1);
    }
    F.col(s) = min(ones(n), max(zeros(n), F.col(s-1) + dF));
  }
  
  std::vector < arma::mat > dM(ncauses);
  for(int c=0; c<ncauses; c++){
    dM[c].set_size(n, event_ind.size());
    dM[c].fill(0.0);
    for(int s=0; s<int(event_ind.size()); s++){
      if(dN[c][s] > 0){
        dM[c].col(s) = ones(n) % ((trunc_time < time[event_ind[s]]) && (time == time[event_ind[s]]) && (event == c+1)) - 
          dLambda[c].col(s) %
          ones(n) % ((trunc_time < time[event_ind[s]]) && (time >= time[event_ind[s]]));
      }
    }
  }
  
  // phi & psi
  arma::mat phi(n, t.size());
  arma::vec phi_count(n, fill::value(0.0));
  std::vector < arma::mat > psi(ncauses);
  std::vector < arma::vec > psi_count_sum2(ncauses);
  for(int c=0; c<ncauses; c++){
    psi[c].set_size(n, t.size());
    psi_count_sum2[c] = zeros(n);
  }
  int counter = 0;
  for(int s=0; s<t.size(); s++){
    if(counter < int(eval_ind.size())){
      while(time[int(eval_ind[counter])] <= t[s]){
        for(int c=0; c<ncauses; c++){
          if(dN[c][counter] > 0){
            if(c == cause-1){
              phi_count += S.col(counter) % (A - Z_bar[cause-1][counter] * ones(n)) % dLambda[cause-1].col(counter);
            }
            psi_count_sum2[c] += F.col(counter+1) % (A - Z_bar[c][counter] * ones(n)) % dLambda[c].col(counter);
          }
        }
        counter++;
        if(counter == int(eval_ind.size())) break;
      }
    }
    std::vector < arma::vec > psi_count_sum1(ncauses);
    for(int c=0; c<ncauses; c++){
      psi_count_sum1[c] = zeros(n);
    }
    if(t[s] >= min(time)){
      arma::uvec eval_ind_t = find((event != 0) && (time <= t[s]));
      for(int r=0; r<int(eval_ind_t.size()); r++){
        for(int c=0; c<ncauses; c++){
          if(dN[c][r] > 0){
            psi_count_sum1[c] += F.col(eval_ind_t.size()) % (A - Z_bar[c][r] * ones(n)) % dLambda[c].col(r);
          }
        }
      }
    }
    phi.col(s) = phi_count;
    for(int c=0; c<ncauses; c++){
      psi[c].col(s) = psi_count_sum1[c] - psi_count_sum2[c];
    }
  }
  
  // omega__inv * (Z_i - Z_bar(u)) * dM_i(u)
  std::vector< arma::vec > sum34_2(ncauses);
  for(int c=0; c<ncauses; c++){
    sum34_2[c] = omega_inv[c] * sum((repelem(A, 1, event_ind.size()) - repelem(Z_bar[c].t(), n, 1)) % dM[c], 1);
  }
  
  // 1/S^0(beta, u) * S(u-) * exp(beta * Z_i) * dM_i(u) & ((F_1(t) - F_1(u)) * sum_k 1/S0(beta, u) * exp(beta_k * Z_i) * dM_ki(u))
  arma::mat sum1(n, t.size(), fill::value(0.0));
  arma::mat sum2(n, t.size(), fill::value(0.0));
  arma::mat sum1_t = S.head_cols(eval_ind.size()) % repelem(exp(A * beta[cause-1]), 1, eval_ind.size()) % dM[cause-1].head_cols(eval_ind.size());
  for(int s=0; s<t.size(); s++){
    if(t[s] >= min(time)){
      arma::uvec eval_ind_t = find((event != 0) && (time <= t[s]));
      arma::mat exp_dM_S0_all(n, eval_ind_t.size());
      for(int c=0; c<ncauses; c++){
        exp_dM_S0_all += repelem(exp(A * beta[c]), 1, eval_ind_t.size()) % dM[c].head_cols(eval_ind_t.size()) / repelem(S0[c].head(eval_ind_t.size()).t(), n, 1);
      }
      if(eval_ind_t.size() > 0){
        sum1.col(s) = sum(sum1_t.head_cols(eval_ind_t.size()), 1);
        sum2.col(s) = sum((repelem(F.col(eval_ind_t.size()), 1, eval_ind_t.size()) - F.cols(1, eval_ind_t.size())) % exp_dM_S0_all, 1);
      }
    }
  }
  
  // martingale residuals
  arma::mat MR(n, t.size(), fill::value(0.0));
  for(int s=0; s<int(t.size()); s++){
    arma::vec sum4(n, fill::value(0.0));
    for(int c=0; c<ncauses; c++){
      sum4 += psi[c].col(s) % sum34_2[c];
    }
     MR.col(s) = (sum1.col(s) - sum2.col(s) + phi.col(s) % sum34_2[cause-1] - sum4) / sqrt(n);
  }
  
  
  // prepare resampling
  
  // identify secondary nearest neighbours 
  arma::uvec snn_A0(n);
  arma::uvec snn_A1(n);
  for(int i=0; i<n; i++){
    int match = -1;
    double dist = arma::math::inf();
    for(int j=0; j<n; j++){
      if(A[j] != A[i]){
        double dist_j = 0.0;
        dist_j += sqrt(sum(pow(Z.row(j) - Z.row(i), 2)));
        if(dist > dist_j){
          match = j;
          dist = dist_j;
        }
      }
    }
    if(A[i] == 0){
      snn_A0[i] = i;
      snn_A1[i] = match;
    }else{
      snn_A0[i] = match;
      snn_A1[i] = i;
    }
  }
  
  // determine PS quintiles
  arma::vec PS_quintiles(4);
  if(n*0.2 > floor(n*0.2)){
    PS_quintiles[0] = 0.5 * (arma::vec(sort(PS))[floor(n*0.2)] +
      arma::vec(sort(PS))[ceil(n*0.2)]);
    PS_quintiles[1] = 0.5 * (arma::vec(sort(PS))[floor(n*0.4)] +
      arma::vec(sort(PS))[ceil(n*0.4)]);
    PS_quintiles[2] = 0.5 * (arma::vec(sort(PS))[floor(n*0.6)] +
      arma::vec(sort(PS))[ceil(n*0.6)]);
    PS_quintiles[3] = 0.5 * (arma::vec(sort(PS))[floor(n*0.8)] +
      arma::vec(sort(PS))[ceil(n*0.8)]);
  }else{
    PS_quintiles[0] = arma::vec(sort(PS))[n*0.2];
    PS_quintiles[1] = arma::vec(sort(PS))[n*0.4];
    PS_quintiles[2] = arma::vec(sort(PS))[n*0.6];
    PS_quintiles[3] = arma::vec(sort(PS))[n*0.8];
  }
  // determine matching function
  arma::vec k_A0(n);
  arma::vec k_A1(n);
  for(int i=0; i<n; i++){
    arma::uvec indices;
    if(PS[i] <= PS_quintiles[0]){
      indices = find((A != A[i]) && (PS <= PS_quintiles[0]));
    }else if(PS[i] <= PS_quintiles[1]){
      indices = find((A != A[i]) &&
        (PS_quintiles[0] < PS) && (PS <= PS_quintiles[1]));
    }else if(PS[i] <= PS_quintiles[2]){
      indices = find((A != A[i]) &&
        (PS_quintiles[1] < PS) && (PS <= PS_quintiles[2]));
    }else if(PS[i] <= PS_quintiles[3]){
      indices = find((A != A[i]) &&
        (PS_quintiles[2] < PS) && (PS <= PS_quintiles[3]));
    }else{
      indices = find((A != A[i]) && (PS_quintiles[3] < PS));
    }
    int index;
    if(indices.size() == 0){
      index = -1;
      double dist = arma::math::inf();
      for(int j=0; j<n; j++){
        if(A[j] != A[i]){
          double dist_new = abs(PS[i] - PS[j]);
          if(dist > dist_new){
            index = j;
            dist = dist_new;
          }
        }
      }
    }else{
      arma::vec u = randn(indices.size());
      index = indices[arma::uvec(find(u == max(u)))[0]];
    }
    if(A[i] == 0){
      k_A0[i] = n_i[i];
      k_A1[i] = n_i[index];
    }else{
      k_A0[i] = n_i[index];
      k_A1[i] = n_i[i];
    }
  }

  // prepare computation of expectation of martingale residuals
  arma::uvec A0 = find(A == 0);
  arma::uvec A1 = find(A == 1);
  arma::rowvec MR_mean_A1 = mean(MR.rows(A1), 0);
  arma::rowvec MR_mean_A0 = mean(MR.rows(A0), 0);
  double PS_mean_A1 = mean(PS.elem(A1));
  double PS_mean_A0 = mean(PS.elem(A0));
  arma::rowvec coef_A1 = sum((MR.rows(A1) - repelem(MR_mean_A1, A1.size(), 1)) % 
    repelem(PS.elem(A1) - PS_mean_A1 * ones(A1.size()), 1, t.size()), 0) / 
    sum(pow(PS.elem(A1) - PS_mean_A1 * ones(A1.size()), 2));
  arma::rowvec coef_A0 = sum((MR.rows(A0) - repelem(MR_mean_A0, A0.size(), 1)) % 
    repelem(PS.elem(A0) - PS_mean_A0 * ones(A0.size()), 1, t.size()), 0) / 
    sum(pow(PS.elem(A0) - PS_mean_A0 * ones(A0.size()), 2));
  
  // resampling
  arma::mat G_BS(A_BS.n_cols, t.size());
  for(int b=0; b<int(A_BS.n_cols); b++){
    for(int s=0; s<int(t.size()); s++){
      
      // expectation of martingale residuals
      arma::vec mu_A1 = MR_mean_A1[s] * ones(n) + (PS_BS.col(b) - PS_mean_A1 * ones(n)) * coef_A1[s];
      arma::vec mu_A0 = MR_mean_A0[s] * ones(n) + (PS_BS.col(b) - PS_mean_A0 * ones(n)) * coef_A0[s];
      
      // bootstrap martingale residuals
      arma::vec MR_bs = mu_A1 - mu_A0 + 
        ((A_BS.col(b) == 1) % ones(n) - (A_BS.col(b) == 0) % ones(n)) % 
        (1 + k_A1 % (A_BS.col(b) == 1) + k_A0 % (A_BS.col(b) == 0)) % 
        ((A_BS.col(b) == 1) % arma::vec(MR.col(s) - mu_A1).rows(snn_A1) + (A_BS.col(b) == 0) % arma::vec(MR.col(s) - mu_A0).rows(snn_A0));
      
      // expectation of bootstrap martingale residuals
      double MR_bs_mean = mean(mu_A1 - mu_A0 + 
                               PS_BS.col(b) % (1 + k_A1) % arma::vec(MR.col(s) - mu_A1).rows(snn_A1) - 
                               (1 - PS_BS.col(b)) % (1 + k_A0) % arma::vec(MR.col(s) - mu_A0).rows(snn_A0));
      
      // compute overall bootstrap martingale residuals
      G_BS(b,s) = sum((MR_bs - MR_bs_mean * ones(n)) % u_BS.col(b)) / sqrt(n);
      
    }
  }
  
  return(G_BS);

}



// [[Rcpp::export]]
List PS_bias(const arma::vec& ID,
              const arma::vec& A,
              const arma::vec& event, 
              const arma::vec& time,
              const std::vector< arma::vec >& beta,
              const arma::vec& PS,
              const NumericVector& t, 
              const Rcpp::Nullable<Rcpp::NumericVector>& trunc_time_init = R_NilValue,
              const int& cause = 1){
  
  int n = time.size();
  int ncauses = beta.size();
  
  // determine number of duplicates of each observation
  arma::vec factor(n, fill::value(0));
  int iter = 0;
  while(iter < n){
    int m_iter = 1;
    for(int iter2=iter+1; iter2<n; iter2++){
      if(ID[iter] == ID[iter2]){
        m_iter++;
      }else{
        break;
      }
    }
    factor[iter] = m_iter;
    iter += m_iter;
  }
  arma::uvec nodup = find(factor > 0);
  
  
  // identify relevant time points
  arma::uvec event_ind = find((event != 0) && (factor > 0));
  arma::uvec eval_ind = find((event != 0) && (factor > 0) && (time <= max(t)));
  
  // implement left-truncation
  arma::vec trunc_time = zeros(n);
  if(trunc_time_init.isNotNull()){
    trunc_time = Rcpp::as<arma::vec>(trunc_time_init);
  }
  
  // dN, Y, S0, Z_bar & omega
  std::vector< arma::vec > dN(ncauses);
  arma::vec Y(event_ind.size());
  std::vector< arma::vec > exp_Zb(ncauses);
  std::vector< arma::vec > exp_Zb_A1(ncauses);
  std::vector< arma::vec > exp_Zb_A0(ncauses); 
  std::vector< arma::vec > S0(ncauses);
  for(int c=0; c<ncauses; c++){
    dN[c] = ones(event_ind.size()) % ((trunc_time.elem(event_ind) < time.elem(event_ind)) && (event.elem(event_ind) == c+1));
    exp_Zb[c] = exp(A.elem(nodup) * beta[c][0] + beta[c][1] * PS.elem(nodup));
    exp_Zb_A1[c] = exp(ones(nodup.size()) * beta[c][0] + beta[c][1] * PS.elem(nodup));
    exp_Zb_A0[c] = exp(beta[c][1] * PS.elem(nodup));
    S0[c].set_size(event_ind.size());
  }
  for(int j=0; j < int(event_ind.size()); j++){
    arma::uvec Y_i = find((trunc_time.elem(nodup) < time[event_ind[j]]) && (time[event_ind[j]] <= time.elem(nodup)));
    for(int c=0; c<ncauses; c++){
      S0[c][j] = sum(arma::vec(factor.elem(nodup)).elem(Y_i) % exp_Zb[c].elem(Y_i)) / double(n);
      
    }
    Y[j] = Y_i.size();
  }
  
  // dLambda
  std::vector < arma::mat > dLambda_A1(ncauses);
  std::vector < arma::mat > dLambda_A0(ncauses);
  for(int c=0; c<ncauses; c++){
    dLambda_A1[c].set_size(nodup.size(), eval_ind.size());
    dLambda_A0[c].set_size(nodup.size(), eval_ind.size());
    for(int s=0; s<int(eval_ind.size()); s++){
      dLambda_A1[c].col(s) = factor[eval_ind[s]] * dN[c][s] * exp_Zb_A1[c] / (double(n)*S0[c][s]);
      dLambda_A0[c].col(s) = factor[eval_ind[s]] * dN[c][s] * exp_Zb_A0[c] / (double(n)*S0[c][s]);
    }
  }
  
  // S & F
  arma::mat F_A1(nodup.size(), t.size());
  arma::mat F_A0(nodup.size(), t.size());
  arma::vec S_A1_pre = ones(nodup.size());
  arma::vec S_A0_pre = ones(nodup.size());
  arma::vec F_A1_pre = zeros(nodup.size());
  arma::vec F_A0_pre = zeros(nodup.size());
  int counter = 0;
  while(time[eval_ind[0]] > t[counter]){
    counter++;
  }
  for(int s=1; s <= int(eval_ind.size()); s++){
    if(counter >= int(t.size())) break;
    arma::vec dLambda_A1_all(nodup.size(), fill::value(0.0));
    arma::vec dLambda_A0_all(nodup.size(), fill::value(0.0));
    for(int c=0; c<ncauses; c++){
      dLambda_A1_all += dLambda_A1[c].col(s-1);
      dLambda_A0_all += dLambda_A0[c].col(s-1);
    }
    arma::vec S_A1_new = min(ones(nodup.size()), max(zeros(nodup.size()), S_A1_pre % (ones(nodup.size()) - dLambda_A1_all)));
    arma::vec S_A0_new = min(ones(nodup.size()), max(zeros(nodup.size()), S_A0_pre % (ones(nodup.size()) - dLambda_A0_all)));
    arma::vec dF_A1(nodup.size(), fill::value(0.0));
    arma::vec dF_A0(nodup.size(), fill::value(0.0));
    if(dN[cause-1][s-1] > 0){
      dF_A1 = S_A1_pre % dLambda_A1[cause-1].col(s-1);
      dF_A0 = S_A0_pre % dLambda_A0[cause-1].col(s-1);
    }
    arma::vec F_A1_new = min(ones(nodup.size()), max(zeros(nodup.size()), F_A1_pre + dF_A1));
    arma::vec F_A0_new = min(ones(nodup.size()), max(zeros(nodup.size()), F_A0_pre + dF_A0));
    if(s == int(eval_ind.size())){
      F_A1.col(counter) = F_A1_new;
      F_A0.col(counter) = F_A0_new;
    }else if((time[eval_ind[s-1]] <= t[counter]) && (time[eval_ind[s]] > t[counter])){
      F_A1.col(counter) = F_A1_new;
      F_A0.col(counter) = F_A0_new;
      counter++;
    }
    if(counter == int(t.size())) break;
    S_A1_pre = S_A1_new;
    S_A0_pre = S_A0_new;
    F_A1_pre = F_A1_new;
    F_A0_pre = F_A0_new;
  }
  if(counter < t.size()){
    for(int s=counter; s<=t.size(); s++){
      F_A1.col(counter) = F_A1.col(counter-1);
      F_A0.col(counter) = F_A0.col(counter-1);
    }
  }
  
  // identify matches
  arma::vec matches(nodup.size());
  for(int i=0; i<int(nodup.size()); i++){
    int match = -1;
    double dist = arma::math::inf();
    for(int j=0; j<int(nodup.size()); j++){
      if(A[nodup[j]] != A[nodup[i]]){
        double dist_j= abs(PS[nodup[i]] - PS[nodup[j]]);
        if(dist > dist_j){
          match = ID[nodup[j]];
          dist = dist_j;
        }
      }
    }
    matches[i] = match;
  }
  
  // identify number of times each individual is used as a match
  arma::vec n_i(nodup.size(), fill::value(0));
  n_i = factor.elem(nodup) - 1;
  for(int i=0; i<int(nodup.size()); i++){
    for(int j=0; j<int(nodup.size()); j++){
      if(matches[j] == ID[nodup[i]]){
        n_i[i] += 1 * factor[nodup[j]];
      }
    }
  }
  
  // compute bias
  arma::vec B(t.size());
  for(int s=0; s<int(t.size()); s++){
    B[s] = sum(((A.elem(nodup) == 1) % ones(nodup.size()) % (F_A0.col(s) + n_i % F_A1.col(s)) -
      (A.elem(nodup) == 0) % ones(nodup.size()) % (F_A1.col(s) + n_i % F_A0.col(s)))) /
        double(n);
  }
   
  List res = List::create(Named("matches") = join_rows(ID.elem(nodup), matches),
                          Named("n_i") = join_rows(ID.elem(nodup), n_i),
                          Named("bias") = B);
  
  return(res);
  
}
