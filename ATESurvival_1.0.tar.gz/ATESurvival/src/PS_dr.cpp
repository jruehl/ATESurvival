// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
//[[Rcpp::depends(RcppClock)]]
#include <RcppClock.h>

using namespace Rcpp;
using namespace arma;
using namespace std;

// [[Rcpp::export]]
List PS_dr(const arma::vec& ID,
           const arma::vec& A,
           const std::vector< arma::mat >& Z,
           const arma::vec& event, 
           const arma::vec& time,
           const arma::vec& beta,
           const arma::vec& PS,
           const arma::vec& pair_ID,
           const NumericVector& t, 
           const arma::mat& A_BS,
           const arma::mat& PS_BS,
           const arma::mat& u_BS,
           const Rcpp::Nullable<Rcpp::NumericVector>& trunc_time_init = R_NilValue, 
           const int& cause = 1,
           const double& level = 0.95){
  
  Rcpp::Clock clock;
  clock.tick("dr");
  
  int n = arma::uvec(find_unique(ID)).size();
  int ncauses = Z.size();
  
  // determine number of duplicates of each observation
  arma::vec factor(time.size(), fill::value(0));
  int iter = 0;
  while(iter < int(time.size())){
    int m_iter = 1;
      for(int iter2=iter+1; iter2<int(time.size()); iter2++){
        if(ID[iter] == ID[iter2]){
          m_iter++;
        }else{
          break;
        }
      }
    factor[iter] = m_iter;
    iter += m_iter;
  }
  arma::uvec nodup = find(factor > 0);
  
  
  // identify secondary nearest neighbours
  std::vector< arma::uvec > snn_A0(ncauses);
  std::vector< arma::uvec > snn_A1(ncauses);
  for(int c=0; c<ncauses; c++){
    snn_A0[c].set_size(nodup.size());
    snn_A1[c].set_size(nodup.size());
    for(int i=0; i<int(nodup.size()); i++){
      int snn = -1;
      double dist = arma::math::inf();
      for(int j=0; j<int(nodup.size()); j++){
        if(A[nodup[j]] != A[nodup[i]]){
          double dist_new = sqrt(sum(pow(Z[c].row(nodup[j]) - Z[c].row(nodup[i]),2)));
          if(dist > dist_new){
            snn = j;
            dist = dist_new;
          }
        }
      }
      if(A[nodup[i]] == 0){
        snn_A0[c][i] = i;
        snn_A1[c][i] = snn;
      }else{
        snn_A0[c][i] = snn;
        snn_A1[c][i] = i;
      }
    }
  }
  
  // determine PS quintiles
  arma::vec PS_quintiles(4);
  if(nodup.size()*0.2 > floor(nodup.size()*0.2)){
    PS_quintiles[0] = 0.5 * (arma::vec(sort(PS.elem(nodup)))[floor(nodup.size()*0.2)] +
      arma::vec(sort(PS.elem(nodup)))[ceil(nodup.size()*0.2)]);
    PS_quintiles[1] = 0.5 * (arma::vec(sort(PS.elem(nodup)))[floor(nodup.size()*0.4)] +
      arma::vec(sort(PS.elem(nodup)))[ceil(nodup.size()*0.4)]);
    PS_quintiles[2] = 0.5 * (arma::vec(sort(PS.elem(nodup)))[floor(nodup.size()*0.6)] +
      arma::vec(sort(PS.elem(nodup)))[ceil(nodup.size()*0.6)]);
    PS_quintiles[3] = 0.5 * (arma::vec(sort(PS.elem(nodup)))[floor(nodup.size()*0.8)] +
      arma::vec(sort(PS.elem(nodup)))[ceil(nodup.size()*0.8)]);
  }else{
    PS_quintiles[0] = arma::vec(sort(PS.elem(nodup)))[nodup.size()*0.2];
    PS_quintiles[1] = arma::vec(sort(PS.elem(nodup)))[nodup.size()*0.4];
    PS_quintiles[2] = arma::vec(sort(PS.elem(nodup)))[nodup.size()*0.6];
    PS_quintiles[3] = arma::vec(sort(PS.elem(nodup)))[nodup.size()*0.8];
  }
  // determine matching function
  arma::vec k_A0(nodup.size());
  arma::vec k_A1(nodup.size());
  for(int i=0; i<int(nodup.size()); i++){
    arma::uvec indices;
    if(PS[nodup[i]] <= PS_quintiles[0]){
      indices = find((A.elem(nodup) != A[nodup[i]]) && (PS.elem(nodup) <= PS_quintiles[0]));
    }else if(PS[nodup[i]] <= PS_quintiles[1]){
      indices = find((A.elem(nodup) != A[nodup[i]]) && 
        (PS_quintiles[0] < PS.elem(nodup)) && (PS.elem(nodup) <= PS_quintiles[1]));
    }else if(PS[nodup[i]] <= PS_quintiles[2]){
      indices = find((A.elem(nodup) != A[nodup[i]]) && 
        (PS_quintiles[1] < PS.elem(nodup)) && (PS.elem(nodup) <= PS_quintiles[2]));
    }else if(PS[nodup[i]] <= PS_quintiles[3]){
      indices = find((A.elem(nodup) != A[nodup[i]]) && 
        (PS_quintiles[2] < PS.elem(nodup)) && (PS.elem(nodup) <= PS_quintiles[3]));
    }else{
      indices = find((A.elem(nodup) != A[nodup[i]]) && (PS_quintiles[3] < PS.elem(nodup)));
    }
    int index;
    if(indices.size() == 0){
      index = -1;
      double dist = arma::math::inf();
      for(int j=0; j<int(nodup.size()); j++){
        if(A[nodup[j]] != A[nodup[i]]){
          double dist_new = abs(PS[nodup[i]] - PS[nodup[j]]);
          if(dist > dist_new){
            index = j;
            dist = dist_new;
          }
        }
      }
    }else{
      arma::vec u = randn(indices.size());
      index = indices[arma::uvec(find(u == max(u)))[0]];
    }
    if(A[nodup[i]] == 0){
      k_A0[i] = factor[nodup[i]] - 1;
      k_A1[i] = factor[nodup[index]] - 1;
    }else{
      k_A0[i] = factor[nodup[index]] - 1;
      k_A1[i] = factor[nodup[i]] - 1;
    }
  }

  
  // identify relevant time points
  arma::uvec event_ind = find((event != 0) && (factor > 0));
  arma::uvec eval_ind = find((event != 0) && (factor > 0) && (time <= max(t)));
  
  // implement left-truncation
  arma::vec trunc_time = zeros(time.size());
  if(trunc_time_init.isNotNull()){
    trunc_time = Rcpp::as<arma::vec>(trunc_time_init);
  }
  
  // dN, Y, S0, Z_bar, omega, dLambda_0, dMi
  std::vector< arma::vec > dN(ncauses);
  arma::vec Y(event_ind.size());
  std::vector< arma::vec > exp_Zb(ncauses);
  std::vector< arma::vec > S0(ncauses);
  std::vector< arma::vec > Z_bar(ncauses);
  arma::vec omega(ncauses);
  std::vector< arma::vec > dLambda_0(ncauses);
  std::vector< arma::mat > dMi(ncauses);
  for(int c=0; c<ncauses; c++){
    dN[c] = factor.elem(event_ind) % ((trunc_time.elem(event_ind) < time.elem(event_ind)) && (event.elem(event_ind) == c+1));
    exp_Zb[c] = exp(A.elem(nodup) * beta[c]);
    S0[c].set_size(event_ind.size());
    Z_bar[c].set_size(event_ind.size());
    omega[c] = 0.0;
    dLambda_0[c].set_size(event_ind.size());
    dMi[c].set_size(nodup.size(), eval_ind.size());
    dMi[c].fill(0.0);
  }
  for(int j=0; j < int(event_ind.size()); j++){
    arma::uvec Y_i = find((trunc_time.elem(nodup) < time[event_ind[j]]) && (time[event_ind[j]] <= time.elem(nodup)));
    for(int c=0; c<ncauses; c++){
      S0[c][j] = 1/double(n) * sum(arma::vec(factor.elem(nodup)).elem(Y_i) % exp_Zb[c].elem(Y_i));
      Z_bar[c][j] = 1/double(n) * sum(arma::vec(factor.elem(nodup)).elem(Y_i) % exp_Zb[c].elem(Y_i) % arma::vec(A.elem(nodup)).elem(Y_i)) / S0[c][j];
      omega[c] += 1/double(n) * (Z_bar[c][j] * (Z_bar[c][j] - 1)) * dN[c][j];
      dLambda_0[c][j] = dN[c][j] / (double(n)*S0[c][j]);
      if(j < int(eval_ind.size())){
        for(int k=0; k<int(Y_i.size()); k++){
          if(k == 0){
            dMi[c](Y_i[k],j) = (dN[c][j] > 0) - dLambda_0[c][j] * exp_Zb[c][Y_i[k]];
          }else{
            dMi[c](Y_i[k],j) = -dLambda_0[c][j] * exp_Zb[c][Y_i[k]];
          }
        }
      }
    }
  }
  
  // martingale increments & expected Score
  std::vector< arma::mat > dMi_A0(ncauses);
  std::vector< arma::mat > dMi_A1(ncauses);
  std::vector< arma::vec > H_A0(ncauses);
  std::vector< arma::vec > H_A1(ncauses);
  for(int c=0; c<ncauses; c++){
    dMi_A0[c].set_size(nodup.size(), eval_ind.size());
    dMi_A1[c].set_size(nodup.size(), eval_ind.size());
    H_A0[c].set_size(nodup.size());
    H_A1[c].set_size(nodup.size());
    for(int i=0; i<int(nodup.size()); i++){
      int s = arma::uvec(find(time[nodup[i]] >= time.elem(event_ind))).size();
      if(A[nodup[i]] == 0){
        int find_match = arma::uvec(find((A == 1) && (pair_ID == pair_ID[nodup[i]])))[0];
        int match = arma::uvec(find(ID.elem(nodup) == ID[find_match]))[0];
        dMi_A0[c].row(i) = dMi[c].row(i);
        dMi_A1[c].row(i) = dMi[c].row(match);
        int s_match = arma::uvec(find(time[nodup[match]] >= time.elem(event_ind))).size();
        H_A0[c][i] = sum((zeros(s) - Z_bar[c].head(s)) %
          (join_cols(zeros(s-1), ones(1)*(event[nodup[i]] == c+1)) - dLambda_0[c].head(s)));
        H_A1[c][i] = sum((ones(s_match) - Z_bar[c].head(s_match)) %
          (join_cols(zeros(s_match-1), ones(1)*(event[nodup[match]] == c+1)) - dLambda_0[c].head(s_match) * exp(beta[c])));
      }else{
        int find_match = arma::uvec(find((A == 0) && (pair_ID == pair_ID[nodup[i]])))[0];
        int match = arma::uvec(find(ID.elem(nodup) == ID[find_match]))[0];
        dMi_A0[c].row(i) = dMi[c].row(match);
        dMi_A1[c].row(i) = dMi[c].row(i);
        int s_match = arma::uvec(find(time[nodup[match]] >= time.elem(event_ind))).size();
        H_A0[c][i] = sum((zeros(s_match) - Z_bar[c].head(s_match)) %
          (join_cols(zeros(s_match-1), ones(1)*(event[nodup[match]] == c+1)) - dLambda_0[c].head(s_match)));
        H_A1[c][i] = sum((ones(s) - Z_bar[c].head(s)) %
          (join_cols(zeros(s-1), ones(1)*(event[nodup[i]] == c+1)) - dLambda_0[c].head(s) * exp(beta[c])));
      }
    }
  }

  
  // S & F
  arma::vec S_A1(int(eval_ind.size()+1));
  arma::vec S_A0(int(eval_ind.size()+1));
  arma::vec F_A1(int(eval_ind.size()+1));
  arma::vec F_A0(int(eval_ind.size()+1));
  S_A1[0] = 1;
  S_A0[0] = 1;
  F_A1[0] = 0;
  F_A0[0] = 0;
  for(int s=1; s <= int(eval_ind.size()); s++){
    double dLambda_A1_all = 0.0;
    double dLambda_A0_all = 0.0;
    for(int c=0; c<ncauses; c++){
      dLambda_A1_all += dLambda_0[c][s-1] * exp(beta[c]);
      dLambda_A0_all += dLambda_0[c][s-1];
    }
    S_A1[s] = min(1.0, max(0.0, S_A1[s-1] * (1.0 - dLambda_A1_all)));
    S_A0[s] = min(1.0, max(0.0, S_A0[s-1] * (1.0 - dLambda_A0_all)));
    double dF_A1 = 0.0;
    double dF_A0 = 0.0;
    if(dN[cause-1][s-1] > 0){
      dF_A1 = S_A1[s-1] * dLambda_0[cause-1][s-1] * exp(beta[cause-1]);
      dF_A0 = S_A0[s-1] * dLambda_0[cause-1][s-1];
    }
    F_A1[s] = min(1.0, max(0.0, F_A1[s-1] + dF_A1));
    F_A0[s] = min(1.0, max(0.0, F_A0[s-1] + dF_A0));
  }
  
  // CIF martingale increments
  int BS_iter = A_BS.n_cols;
  
  std::vector< arma::mat > dW_a0(ncauses);
  std::vector< arma::mat > dW_a1(ncauses);
  for(int c=0; c<ncauses; c++){
    dW_a0[c].set_size(eval_ind.size(), BS_iter);
    dW_a1[c].set_size(eval_ind.size(), BS_iter);
    for(int b=0; b<BS_iter; b++){
      double mu_H_A0 =
        mean(H_A0[c]) -
        sum((H_A0[c] - mean(H_A0[c])) % (PS_BS.col(b) - mean(PS_BS.col(b)))) /
        sum(pow(PS_BS.col(b) - mean(PS_BS.col(b)), 2)) *
        (mean(PS_BS.col(b)) - mean(arma::vec(PS_BS.col(b)).elem(find(A_BS.col(b) == 0))));
      double mu_H_A1 =
        mean(H_A1[c]) -
        sum((H_A1[c] - mean(H_A1[c])) % (PS_BS.col(b) - mean(PS_BS.col(b)))) /
        sum(pow(PS_BS.col(b) - mean(PS_BS.col(b)), 2)) *
        (mean(PS_BS.col(b)) - mean(arma::vec(PS_BS.col(b)).elem(find(A_BS.col(b) == 1))));
      arma::rowvec mu_dM_A0 =
        mean(dMi_A0[c], 0) -
        sum((dMi_A0[c].each_row() - mean(dMi_A0[c], 0)) % repelem(PS_BS.col(b) - mean(PS_BS.col(b)), 1, eval_ind.size()), 0) /
        arma::rowvec(sum(pow(PS_BS.col(b) - mean(PS_BS.col(b)), 2)) * ones(eval_ind.size()).t()) %
        arma::rowvec((mean(PS_BS.col(b)) - mean(arma::vec(PS_BS.col(b)).elem(find(A_BS.col(b) == 0)))) * ones(eval_ind.size()).t());
      arma::rowvec mu_dM_A1 =
        mean(dMi_A1[c], 0) -
        sum((dMi_A1[c].each_row() - mean(dMi_A1[c], 0)) % repelem(PS_BS.col(b) - mean(PS_BS.col(b)), 1, eval_ind.size()), 0) /
        arma::rowvec(sum(pow(PS_BS.col(b) - mean(PS_BS.col(b)), 2)) * ones(eval_ind.size()).t()) %
        arma::rowvec((mean(PS_BS.col(b)) - mean(arma::vec(PS_BS.col(b)).elem(find(A_BS.col(b) == 1)))) * ones(eval_ind.size()).t());
      arma::vec r = (mu_H_A0 + mu_H_A1) * ones(nodup.size());
      arma::mat dM_BS = repelem(mu_dM_A0 + mu_dM_A1, nodup.size(), 1);
      double r_mean = mu_H_A0 + mu_H_A1;
      arma::rowvec dM_BS_mean = mu_dM_A0 + mu_dM_A1;
      for(int i=0; i<int(nodup.size()); i++){
        if(A_BS(i,b) == 0){
          r[i] += (1+k_A0[i]) * (H_A0[c][snn_A0[c][i]] - mu_H_A0);
          dM_BS.row(i) += (1+k_A0[i]) * (dMi_A0[c].row(snn_A0[c][i]) - mu_dM_A0);
        }else{
          r[i] += (1+k_A1[i]) * (H_A1[c][snn_A1[c][i]] - mu_H_A1);
          dM_BS.row(i) += (1+k_A1[i]) * (dMi_A1[c].row(snn_A1[c][i]) - mu_dM_A1);
        }
        r_mean += 1/double(n) * (
          PS_BS(i,b) * (1+k_A1[i]) * (H_A1[c][snn_A1[c][i]] - mu_H_A1) +
            (1-PS_BS(i,b)) * (1+k_A0[i]) * (H_A0[c][snn_A0[c][i]] - mu_H_A0)
        );
        dM_BS_mean += 1/double(n) * (
          PS_BS(i,b) * (1+k_A1[i]) * (dMi_A1[c].row(snn_A1[c][i]) - mu_dM_A1) +
            (1-PS_BS(i,b)) * (1+k_A0[i]) * (dMi_A0[c].row(snn_A0[c][i]) - mu_dM_A0)
        );
      }
      dW_a0[c].col(b) = (
        sum((dM_BS.each_row() - dM_BS_mean) % repelem(u_BS.col(b), 1, eval_ind.size()), 0).t() / S0[c].head(eval_ind.size()) +
        (zeros(eval_ind.size()) - Z_bar[c].head(eval_ind.size())) % dLambda_0[c].head(eval_ind.size()) / omega[c] *
        sum((r - r_mean*ones(nodup.size())) % u_BS.col(b))
      ) / sqrt(n);
      dW_a1[c].col(b) = (
        sum((dM_BS.each_row() - dM_BS_mean) % repelem(u_BS.col(b), 1, eval_ind.size()), 0).t() / S0[c].head(eval_ind.size()) * exp(beta[c]) +
          (ones(eval_ind.size()) - Z_bar[c].head(eval_ind.size())) % dLambda_0[c].head(eval_ind.size()) * exp(beta[c]) / omega[c] *
          sum((r - r_mean*ones(nodup.size())) % u_BS.col(b))
      ) / sqrt(n);
    }
    //   dW_a0[c].set_size(eval_ind.size(), BS_iter);
    //   dW_a1[c].set_size(eval_ind.size(), BS_iter);
    //   arma::mat dWi_A0 = (
    //     dMi_A0[c] / repelem(S0[c].head(eval_ind.size()).t(), nodup.size(), 1) +
    //       repelem(((zeros(eval_ind.size()) - Z_bar[c].head(eval_ind.size())) % dLambda_0[c].head(eval_ind.size()) / omega[c]).t(), nodup.size(), 1) %
    //       repelem(H_A0[c], 1, eval_ind.size())
    //   ) / sqrt(n);
    //   arma::mat dWi_A1 = (
    //     dMi_A1[c] / repelem(S0[c].head(eval_ind.size()).t(), nodup.size(), 1) +
    //       repelem(((zeros(eval_ind.size()) - Z_bar[c].head(eval_ind.size())) % dLambda_0[c].head(eval_ind.size()) / omega[c]).t(), nodup.size(), 1) %
    //       repelem(H_A1[c], 1, eval_ind.size())
    //   ) / sqrt(n);
    //   for(int b=0; b<BS_iter; b++){
    //     arma::rowvec mu_dWi_A0_a0 =
    //       mean(dWi_A0, 0) -
    //       sum((dWi_A0.each_row() - mean(dWi_A0, 0)) % repelem(PS_BS.col(b) - mean(PS_BS.col(b)), 1, eval_ind.size()), 0) /
    //       arma::rowvec(sum(pow(PS_BS.col(b) - mean(PS_BS.col(b)), 2)) * ones(eval_ind.size()).t()) %
    //       arma::rowvec((mean(PS_BS.col(b)) - mean(arma::vec(PS_BS.col(b)).elem(find(A_BS.col(b) == 0)))) * ones(eval_ind.size()).t());
    //     arma::rowvec mu_dWi_A0_a1 =
    //       exp(beta[c]) * mean(dWi_A0, 0) -
    //       sum(exp(beta[c]) * (dWi_A0.each_row() - mean(dWi_A0, 0)) % repelem(PS_BS.col(b) - mean(PS_BS.col(b)), 1, eval_ind.size()), 0) /
    //       arma::rowvec(sum(pow(PS_BS.col(b) - mean(PS_BS.col(b)), 2)) * ones(eval_ind.size()).t()) %
    //       arma::rowvec((mean(PS_BS.col(b)) - mean(arma::vec(PS_BS.col(b)).elem(find(A_BS.col(b) == 0)))) * ones(eval_ind.size()).t());
    //     arma::rowvec mu_dWi_A1_a0 =
    //       mean(dWi_A1, 0) -
    //       sum((dWi_A1.each_row() - mean(dWi_A1, 0)) % repelem(PS_BS.col(b) - mean(PS_BS.col(b)), 1, eval_ind.size()), 0) /
    //       arma::rowvec(sum(pow(PS_BS.col(b) - mean(PS_BS.col(b)), 2)) * ones(eval_ind.size()).t()) %
    //       arma::rowvec((mean(PS_BS.col(b)) - mean(arma::vec(PS_BS.col(b)).elem(find(A_BS.col(b) == 1)))) * ones(eval_ind.size()).t());
    //     arma::rowvec mu_dWi_A1_a1=
    //       exp(beta[c]) * mean(dWi_A1, 0) -
    //       sum(exp(beta[c]) * (dWi_A1.each_row() - mean(dWi_A1, 0)) % repelem(PS_BS.col(b) - mean(PS_BS.col(b)), 1, eval_ind.size()), 0) /
    //       arma::rowvec(sum(pow(PS_BS.col(b) - mean(PS_BS.col(b)), 2)) * ones(eval_ind.size()).t()) %
    //       arma::rowvec((mean(PS_BS.col(b)) - mean(arma::vec(PS_BS.col(b)).elem(find(A_BS.col(b) == 1)))) * ones(eval_ind.size()).t());
    //     arma::mat dW_a0_BS = repelem(mu_dWi_A0_a0 + mu_dWi_A1_a0, nodup.size(), 1);
    //     arma::mat dW_a1_BS = repelem(mu_dWi_A0_a1 + mu_dWi_A1_a1, nodup.size(), 1);
    //     arma::rowvec dW_a0_mean = mu_dWi_A0_a0 + mu_dWi_A1_a0;
    //     arma::rowvec dW_a1_mean = mu_dWi_A0_a1 + mu_dWi_A1_a1;
    // 
    //     for(int i=0; i<int(nodup.size()); i++){
    //       if(A_BS(i,b) == 0){
    //         dW_a0_BS.row(i) += (1+k_A0[i]) * (dWi_A0.row(snn_A0[c][i]) - mu_dWi_A0_a0);
    //         dW_a1_BS.row(i) += (1+k_A0[i]) * (exp(beta[c]) * dWi_A0.row(snn_A0[c][i]) - mu_dWi_A0_a1);
    //       }else{
    //         dW_a0_BS.row(i) += (1+k_A1[i]) * (dWi_A1.row(snn_A1[c][i]) - mu_dWi_A1_a0);
    //         dW_a1_BS.row(i) += (1+k_A1[i]) * (exp(beta[c]) * dWi_A1.row(snn_A1[c][i]) - mu_dWi_A1_a1);
    //       }
    //       dW_a0_mean += (PS_BS(i,b) * (1+k_A1[i]) * (dWi_A1.row(snn_A1[c][i]) - mu_dWi_A1_a0) +
    //         (1-PS_BS(i,b)) * (1+k_A0[i]) * (dWi_A0.row(snn_A0[c][i]) - mu_dWi_A0_a0)) /
    //         double(n);
    //       dW_a1_mean += (PS_BS(i,b) * (1+k_A1[i]) * (exp(beta[c]) * dWi_A1.row(snn_A1[c][i]) - mu_dWi_A1_a1) +
    //         (1-PS_BS(i,b)) * (1+k_A0[i]) * (exp(beta[c]) * dWi_A0.row(snn_A0[c][i]) - mu_dWi_A0_a1)) /
    //         double(n);
    //     }
    //     dW_a0[c].col(b) = sum((dW_a0_BS.each_row() - dW_a0_mean) % repelem(u_BS.col(b), 1, eval_ind.size()), 0).t();
    //     dW_a1[c].col(b) = sum((dW_a1_BS.each_row() - dW_a1_mean) % repelem(u_BS.col(b), 1, eval_ind.size()), 0).t();
    //   }
  }
  
  // ATE process
  arma::mat U_n(t.size(), BS_iter, fill::value(0.0));
  arma::rowvec U_n_count(BS_iter, fill::value(0.0));
  int counter = 0;
  for(int s=0; s<int(t.size()); s++){
    if(counter == int(eval_ind.size())){
      U_n.row(s) = U_n_count;
      for(int c=0; c<ncauses; c++){
        U_n.row(s) -= F_A1[counter] * sum(dW_a1[c].head_rows(counter), 0) -
          F_A0[counter] * sum(dW_a0[c].head_rows(counter), 0);
      }
      continue;
    }
    while(time[int(eval_ind[counter])] <= t[s]){
      U_n_count += S_A1[counter] * dW_a1[cause-1].row(counter) -
        S_A0[counter] * dW_a0[cause-1].row(counter);
      for(int c=0; c<ncauses; c++){
        U_n_count += F_A1[counter+1] * dW_a1[c].row(counter) -
          F_A0[counter+1] * dW_a0[c].row(counter);
      }
      counter++;
      if(counter == int(eval_ind.size())) break;
    }
    U_n.row(s) = U_n_count;
    for(int c=0; c<ncauses; c++){
      U_n.row(s) -= F_A1[counter] * sum(dW_a1[c].head_rows(counter), 0) -
        F_A0[counter] * sum(dW_a0[c].head_rows(counter), 0);
    }
  }
  
  // CIs
  arma::mat CI(2, t.size(), fill::value(0.0));
  for(int s=0; s<int(t.size()); s++){
    if(t[s] > min(time)){
      arma::uvec eval_ind_t = find((event != 0) && (factor > 0) && (time <= t[s]));
      double q = arma::rowvec(sort(abs(U_n.row(s))))[round(BS_iter * level)];
      CI(0,s) = max(F_A1[eval_ind_t.size()] - F_A0[eval_ind_t.size()] - q / sqrt(n), double(-1));
      CI(1,s) = min(F_A1[eval_ind_t.size()] - F_A0[eval_ind_t.size()] + q / sqrt(n), double(1));
    }
  }
  
  // CBs
  arma::mat CB(2, t.size(), fill::value(0.0));
  arma::vec sd(t.size());
  arma::mat q_t(t.size(), BS_iter);
  for(int s=0; s<int(t.size()); s++){
    sd[s] = stddev(U_n.row(s));
    q_t.row(s) = abs(U_n.row(s) / sd[s]);
  }
  double q = arma::rowvec(sort(max(q_t, 0)))[round(BS_iter * level)];
  for(int s=0; s<int(t.size()); s++){
    if(t[s] > min(time)){
      arma::uvec eval_ind_t = find((event != 0) && (factor > 0) && (time <= t[s]));
      CB(0,s) = max(F_A1[eval_ind_t.size()] - F_A0[eval_ind_t.size()] - q * sd[s] / sqrt(n), double(-1));
      CB(1,s) = min(F_A1[eval_ind_t.size()] - F_A0[eval_ind_t.size()] + q * sd[s]/ sqrt(n), double(1));
    }
  }
  
  clock.tock("dr");
  clock.stop("clock");
  
  
  List res = List::create(Named("CI") = CI, Named("CB") = CB);
  
  return(res);
  
}
