// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
//[[Rcpp::depends(RcppClock)]]
#include <RcppClock.h>

using namespace Rcpp;
using namespace arma;
using namespace std;

// [[Rcpp::export]]
List ATE(const arma::vec& ID,
         const std::vector< arma::mat >& Z,
         const std::vector< int >& index_A,
         const arma::vec& event, 
         const arma::vec& time,
         const std::vector< arma::vec >& beta,
         const NumericVector& t, 
         const Rcpp::Nullable<Rcpp::NumericVector>& trunc_time_init = R_NilValue, 
         const Rcpp::Nullable<Rcpp::NumericVector>& cluster_init = R_NilValue,
         const int& cause = 1,
         const bool& IF = true,
         const bool& IF_CI_CB = true,
         const Rcpp::Nullable<Rcpp::NumericVector>& G_IF_init = R_NilValue,
         const bool& WBS = true,
         const bool& WBS_CI_CB = true,
         const Rcpp::Nullable<Rcpp::NumericVector>& G_WBS_init = R_NilValue,
         const int& bs_iter = 1e4, 
         const double& level = 0.95){
  
  Rcpp::Clock clock;
  clock.tick("ATE");
  
  int n = Z[cause-1].n_rows;
  int ncauses = Z.size();
  
  // identify clusters & cluster sizes
  arma::vec cluster(n);
  if(cluster_init.isNotNull()){
    cluster = Rcpp::as<arma::vec>(cluster_init);
  }else{
    for(int i=0; i<n; i++){
      cluster[i] = i+1;
    }
  }
  int nclusters = arma::vec(unique(cluster)).size();
  arma::vec clustersize(n);
  for(int i=0; i<n; i++){
    clustersize[i] = arma::uvec(find(cluster == cluster[i])).size();
  }
  
  // determine number of duplicates of each observation
  arma::vec factor(n, fill::value(0));
  int iter = 0;
  while(iter < n){
    int m_iter = 1;
      for(int iter2=iter+1; iter2<n; iter2++){
        if(ID[iter] == ID[iter2]){
          m_iter++;
        }else{
          break;
        }
      }
    factor[iter] = m_iter;
    iter += m_iter;
  }
  arma::uvec nodup = find(factor > 0);
  
  // determine cluster weights
  arma::vec weights_cluster_all_t(nodup.size());
  for(int s=0; s<int(nodup.size()); s++){
    weights_cluster_all_t[s] = sum(ones(factor[nodup[s]]) / clustersize.subvec(nodup[s], nodup[s]+factor[nodup[s]]-1));
  }
  arma::vec weights_cluster = weights_cluster_all_t.elem(find(event.elem(nodup) != 0));
  
  
  // identify relevant time points
  arma::uvec event_ind = find((event != 0) && (factor > 0));
  arma::uvec eval_ind = find((event != 0) && (factor > 0) && (time <= max(t)));
  
  // implement left-truncation
  arma::vec trunc_time = zeros(n);
  if(trunc_time_init.isNotNull()){
    trunc_time = Rcpp::as<arma::vec>(trunc_time_init);
  }
  
  // dN, Y, S0, Z_bar & omega
  std::vector< arma::vec > dN(ncauses);
  arma::vec Y(event_ind.size());
  std::vector < arma::mat > Z_A1(ncauses);
  std::vector < arma::mat > Z_A0(ncauses);
  std::vector< arma::vec > exp_Zb(ncauses);
  std::vector< arma::vec > exp_Zb_A1(ncauses);
  std::vector< arma::vec > exp_Zb_A0(ncauses); 
  std::vector< arma::vec > S0(ncauses);
  std::vector< arma::mat > Z_bar(ncauses);
  std::vector< arma::mat > omega(ncauses);
  std::vector< arma::mat > omega_inv(ncauses);
  for(int c=0; c<ncauses; c++){
    dN[c] = ones(event_ind.size()) % ((trunc_time.elem(event_ind) < time.elem(event_ind)) && (event.elem(event_ind) == c+1));
    Z_A1[c] = Z[c].rows(nodup);
    Z_A0[c] = Z[c].rows(nodup);
    if(index_A[c] > 0){
      Z_A1[c].col(index_A[c]-1) = ones(nodup.size());
      Z_A0[c].col(index_A[c]-1) = zeros(nodup.size());
    }
    exp_Zb[c] = exp(Z[c].rows(nodup) * beta[c]);
    exp_Zb_A1[c] = exp(Z_A1[c] * beta[c]);
    exp_Zb_A0[c] = exp(Z_A0[c] * beta[c]);
    S0[c].set_size(event_ind.size());
    if(IF || WBS){
      Z_bar[c].set_size(event_ind.size(), Z[c].n_cols);
      omega[c].set_size(Z[c].n_cols, Z[c].n_cols);
      omega[c].fill(0.0);
    }
  }
  for(int j=0; j < int(event_ind.size()); j++){
    arma::uvec Y_i = find((trunc_time.elem(nodup) < time[event_ind[j]]) && (time[event_ind[j]] <= time.elem(nodup)));
    for(int c=0; c<ncauses; c++){
      S0[c][j] = sum(weights_cluster_all_t.elem(Y_i) % exp_Zb[c].elem(Y_i)) / double(nclusters);
      if(IF || WBS){
        Z_bar[c].row(j) = (weights_cluster_all_t.elem(Y_i) % exp_Zb[c].elem(Y_i)).t() * arma::mat(Z[c].rows(nodup)).rows(Y_i) / (double(nclusters) * S0[c][j]);
        arma::mat exp_Zb_Z = arma::mat(Z[c].rows(nodup)).rows(Y_i);
        exp_Zb_Z.each_col() %=  weights_cluster_all_t.elem(Y_i) % exp_Zb[c].elem(Y_i);
        arma::mat S2 = (exp_Zb_Z).t() * arma::mat(Z[c].rows(nodup)).rows(Y_i) / double(nclusters);
        omega[c] += weights_cluster[j] * (S2/S0[c][j] - Z_bar[c].row(j).t() * Z_bar[c].row(j)) * dN[c][j] / double(nclusters);
      }
    }
    Y[j] = Y_i.size();
  }
  if(IF || WBS){
    for(int c=0; c<ncauses; c++){
      omega_inv[c] = inv_sympd(omega[c]);
    }
  }
  
  // dLambda
  std::vector < arma::mat > dLambda_A1(ncauses);
  std::vector < arma::mat > dLambda_A0(ncauses);
  for(int c=0; c<ncauses; c++){
    dLambda_A1[c].set_size(nodup.size(), eval_ind.size());
    dLambda_A0[c].set_size(nodup.size(), eval_ind.size());
    for(int s=0; s<int(eval_ind.size()); s++){
      dLambda_A1[c].col(s) = weights_cluster[s] * dN[c][s] * exp_Zb_A1[c] / (double(nclusters)*S0[c][s]);
      dLambda_A0[c].col(s) = weights_cluster[s] * dN[c][s] * exp_Zb_A0[c] / (double(nclusters)*S0[c][s]);
    }
  }
  
  // S & F
  arma::mat S_A1(nodup.size(), int(eval_ind.size()+1));
  arma::mat S_A0(nodup.size(), int(eval_ind.size()+1));
  arma::mat F_A1(nodup.size(), int(eval_ind.size()+1));
  arma::mat F_A0(nodup.size(), int(eval_ind.size()+1));
  S_A1.col(0) = ones(nodup.size());
  S_A0.col(0) = ones(nodup.size());
  F_A1.col(0) = zeros(nodup.size());
  F_A0.col(0) = zeros(nodup.size());
  for(int s=1; s <= int(eval_ind.size()); s++){
    arma::vec dLambda_A1_all(nodup.size(), fill::value(0.0));
    arma::vec dLambda_A0_all(nodup.size(), fill::value(0.0));
    for(int c=0; c<ncauses; c++){
      dLambda_A1_all += dLambda_A1[c].col(s-1);
      dLambda_A0_all += dLambda_A0[c].col(s-1);
    }
    S_A1.col(s) = min(ones(nodup.size()), max(zeros(nodup.size()), S_A1.col(s-1) % (1.0 - dLambda_A1_all)));
    S_A0.col(s) = min(ones(nodup.size()), max(zeros(nodup.size()), S_A0.col(s-1) % (1.0 - dLambda_A0_all)));
    arma::vec dF_A1(nodup.size(), fill::value(0.0));
    arma::vec dF_A0(nodup.size(), fill::value(0.0));
    if(dN[cause-1][s-1] > 0){
      dF_A1 = S_A1.col(s-1) % dLambda_A1[cause-1].col(s-1);
      dF_A0 = S_A0.col(s-1) % dLambda_A0[cause-1].col(s-1);
    }
    F_A1.col(s) = min(ones(nodup.size()), max(zeros(nodup.size()), F_A1.col(s-1) + dF_A1));
    F_A0.col(s) = min(ones(nodup.size()), max(zeros(nodup.size()), F_A0.col(s-1) + dF_A0));
  }
  
  // mean F
  arma::vec F_A1_mean(t.size(), fill::value(0.0));
  arma::vec F_A0_mean(t.size(), fill::value(0.0));
  for(int s=0; s<t.size(); s++){
    if(t[s] >= min(time)){
      arma::uvec eval_ind_t = find((event.elem(nodup) != 0) && (time.elem(nodup) <= t[s]));
      F_A1_mean[s] = sum(F_A1.col(eval_ind_t.size()) % weights_cluster_all_t)/double(nclusters);
      F_A0_mean[s] = sum(F_A0.col(eval_ind_t.size()) % weights_cluster_all_t)/double(nclusters);
    }
  }
  
  clock.tock("ATE");
  
  
  clock.tick("IF");
  arma::vec SE_IF(t.size());
  arma::mat Un_std_IF;
  arma::mat CI_IF;
  arma::mat CB_IF;
  
  if(IF){
    
    // influence functions
    
    // IF_beta
    std::vector< arma::mat > IF_beta(ncauses);
    for(int c=0; c<ncauses; c++){
      IF_beta[c].set_size(nodup.size(), Z[c].n_cols);
      IF_beta[c].fill(0.0);
      for(int i=0; i<int(nodup.size()); i++){
        arma::uvec i_event_ind = find(time[nodup[i]] == time.elem(event_ind));
        if(i_event_ind.size() > 0){
          IF_beta[c].row(i) = (Z[c].row(nodup[i]) - Z_bar[c].rows(i_event_ind)) * as_scalar(dN[c].elem(i_event_ind)) * omega_inv[c].t();
        }
        arma::rowvec IF_beta_2(Z[c].n_cols, fill::value(0.0));
        int j=0;
        while(time[event_ind[j]] <= time[nodup[i]]){
          IF_beta_2 += (Z[c].row(nodup[i]) - Z_bar[c].row(j)) * weights_cluster[j] * dN[c][j] / (double(nclusters)*S0[c][j]);
          j++;
          if(j == int(event_ind.size())) break;
        }
        IF_beta[c].row(i) -= exp_Zb[c][i] * IF_beta_2 * omega_inv[c].t();
      }
    }
    
    // dIF_Lambda_0
    std::vector< arma::mat > dIF_Lambda_0(ncauses);
    for(int c=0; c<ncauses; c++){
      dIF_Lambda_0[c].set_size(nodup.size(), int(eval_ind.size()+1));
      dIF_Lambda_0[c].fill(0.0);
      for(int s=1; s <= int(eval_ind.size()); s++){
        dIF_Lambda_0[c].col(s) = -IF_beta[c] * Z_bar[c].row(s-1).t() * weights_cluster[s-1] * dN[c][s-1] / (double(nclusters)*S0[c][s-1]);
        if(dN[c][s-1] > 0){
          dIF_Lambda_0[c].col(s) -= (time[eval_ind[s-1]] <= time.elem(nodup)) % exp_Zb[c] * weights_cluster[s-1] * dN[c][s-1] / (double(nclusters) * pow(S0[c][s-1], 2));
          dIF_Lambda_0[c](arma::uvec(find((event.elem(nodup) != 0) && (time.elem(nodup) <= max(t))))[s-1], s) += dN[c][s-1] / S0[c][s-1];
        }
      }
    }
    
    // IF_F
    arma::mat IF_F_A1_mean(nodup.size(), t.size(), fill::value(0.0));
    arma::mat IF_F_A0_mean(nodup.size(), t.size(), fill::value(0.0));
    arma::vec IF_F_A1_mean_count(nodup.size(), fill::value(0.0));
    arma::vec IF_F_A0_mean_count(nodup.size(), fill::value(0.0));
    int counter = 0;
    for(int s=0; s < int(t.size()); s++){
      if(counter == int(eval_ind.size())){
        IF_F_A1_mean.col(s) = IF_F_A1_mean_count;
        IF_F_A0_mean.col(s) = IF_F_A0_mean_count;
        continue;
      }
      while(time[int(eval_ind[counter])] <= t[s]){
        if(dN[cause-1][counter] > 0){
          for(int c=0; c<ncauses; c++){
            IF_F_A1_mean_count -= sum(weights_cluster_all_t % S_A1.col(counter) % exp_Zb_A1[c] % dLambda_A1[cause-1].col(counter)) * sum(dIF_Lambda_0[c].head_cols(counter+1), 1) / double(nclusters);
            IF_F_A0_mean_count -= sum(weights_cluster_all_t % S_A0.col(counter) % exp_Zb_A0[c] % dLambda_A0[cause-1].col(counter)) * sum(dIF_Lambda_0[c].head_cols(counter+1), 1) / double(nclusters);
            if(counter > 0){
              arma::mat S_exp_Zb_dLambda_Z_A1 = Z_A1[c];
              arma::mat S_exp_Zb_dLambda_Z_A0 = Z_A0[c];
              S_exp_Zb_dLambda_Z_A1.each_col() %= weights_cluster_all_t % S_A1.col(counter) % exp_Zb_A1[c] % dLambda_A1[cause-1].col(counter);
              S_exp_Zb_dLambda_Z_A0.each_col() %= weights_cluster_all_t % S_A0.col(counter) % exp_Zb_A0[c] % dLambda_A0[cause-1].col(counter);
              double Lambda_0 = sum(weights_cluster.head(counter) % dN[c].head(counter) / (double(nclusters) * S0[c].head(counter)));
              IF_F_A1_mean_count -= IF_beta[c] * sum(S_exp_Zb_dLambda_Z_A1, 0).t() * Lambda_0 / double(nclusters);
              IF_F_A0_mean_count -= IF_beta[c] * sum(S_exp_Zb_dLambda_Z_A0, 0).t() * Lambda_0 / double(nclusters);
            }
          }
          IF_F_A1_mean_count += sum(weights_cluster_all_t % S_A1.col(counter) % exp_Zb_A1[cause-1]) * dIF_Lambda_0[cause-1].col(counter+1) / double(nclusters);
          IF_F_A0_mean_count += sum(weights_cluster_all_t % S_A0.col(counter) % exp_Zb_A0[cause-1]) * dIF_Lambda_0[cause-1].col(counter+1) / double(nclusters);
          arma::mat S_dLambda_A1 = Z_A1[cause-1];
          arma::mat S_dLambda_A0 = Z_A0[cause-1];
          S_dLambda_A1.each_col() %= weights_cluster_all_t % S_A1.col(counter) % dLambda_A1[cause-1].col(counter);
          S_dLambda_A0.each_col() %= weights_cluster_all_t % S_A0.col(counter) % dLambda_A0[cause-1].col(counter);
          IF_F_A1_mean_count += IF_beta[cause-1] * sum(S_dLambda_A1, 0).t() / double(nclusters);
          IF_F_A0_mean_count += IF_beta[cause-1] * sum(S_dLambda_A0, 0).t() / double(nclusters);
        }
        counter++;
        if(counter == int(eval_ind.size())) break;
      }
      IF_F_A1_mean.col(s) = IF_F_A1_mean_count;
      IF_F_A0_mean.col(s) = IF_F_A0_mean_count;
    }
    
    // IF_ATE
    arma::mat IF_ATE(nodup.size(), t.size(), fill::value(0.0));
    for(int s=0; s<t.size(); s++){
      if(t[s] >= min(time)){
        arma::uvec eval_ind_t = find((event.elem(nodup) != 0) && (time.elem(nodup) <= t[s]));
        IF_ATE.col(s) = (F_A1.col(int(eval_ind_t.size())) - F_A0.col(int(eval_ind_t.size()))) - 
         (F_A1_mean[s] - F_A0_mean[s]) * ones(nodup.size()) + 
          IF_F_A1_mean.col(s) - IF_F_A0_mean.col(s);
      }
    }
    
    // SE_IF
    for(int s=0; s<t.size(); s++){
      SE_IF[s] = sqrt(as_scalar(sum(pow(weights_cluster_all_t % IF_ATE.col(s) / double(nclusters), 2))));
    }
    
    // BS multipliers
    arma::mat G_IF;
    if(G_IF_init.isNotNull()){
      G_IF = Rcpp::as<arma::vec>(G_IF_init);
      G_IF.reshape(bs_iter, nodup.size());
    }else{
      G_IF.randn(bs_iter, nodup.size());
    }
    // Un
    Un_std_IF = IF_ATE.cols(find(SE_IF > 0));
    Un_std_IF.each_col() %= weights_cluster_all_t / double(nclusters);
    Un_std_IF.each_row() /= SE_IF.elem(find(SE_IF > 0)).t();
    Un_std_IF = abs(G_IF * Un_std_IF);
    
    clock.tick("IF_CI_CB");
    if(IF_CI_CB){
      // CIs
      CI_IF = join_rows(max(F_A1_mean - F_A0_mean - SE_IF * R::qnorm(1-(1-level)/2, 0.0, 1.0, 1, 0), -1 * ones(t.size())),
                        min(F_A1_mean - F_A0_mean + SE_IF * R::qnorm(1-(1-level)/2, 0.0, 1.0, 1, 0), ones(t.size()))).t();
      // CBs
      arma::vec q_IF = max(Un_std_IF, 1);
      CB_IF = join_rows(max(F_A1_mean - F_A0_mean - SE_IF * arma::vec(sort(q_IF))[round(bs_iter * level)], -1 * ones(t.size())),
                        min(F_A1_mean - F_A0_mean + SE_IF * arma::vec(sort(q_IF))[round(bs_iter * level)], ones(t.size()))).t(); 
    }
    clock.tock("IF_CI_CB");
    
  }
  
  clock.tock("IF");
  
  clock.tick("WBS");
  arma::rowvec SD_WBS(t.size());
  arma::mat _WBS;
  arma::mat Un_std_WBS;
  arma::mat CI_WBS;
  arma::mat CB_WBS;
  
  if(WBS){
    
    // BS multipliers
    arma::mat G_WBS;
    if(G_WBS_init.isNotNull()){
      G_WBS = Rcpp::as<arma::vec>(G_WBS_init);
      G_WBS.reshape(event_ind.size(), bs_iter);
    }else{
      G_WBS.randn(event_ind.size(), bs_iter);
    }
    
    // mean phi & mean psi
    arma::mat phi_A1(t.size(), Z[cause-1].n_cols);
    arma::mat phi_A0(t.size(), Z[cause-1].n_cols);
    arma::rowvec phi_A1_count(Z[cause-1].n_cols, fill::value(0.0));
    arma::rowvec phi_A0_count(Z[cause-1].n_cols, fill::value(0.0));
    std::vector < arma::mat > psi_A1(ncauses);
    std::vector < arma::mat > psi_A0(ncauses);
    std::vector < arma::rowvec > psi_A1_count_sum2(ncauses);
    std::vector < arma::rowvec > psi_A0_count_sum2(ncauses);
    for(int c=0; c<ncauses; c++){
      psi_A1[c].set_size(t.size(), Z[c].n_cols);
      psi_A0[c].set_size(t.size(), Z[c].n_cols);
      psi_A1_count_sum2[c].set_size(Z[c].n_cols);
      psi_A1_count_sum2[c].fill(0.0);
      psi_A0_count_sum2[c].set_size(Z[c].n_cols);
      psi_A0_count_sum2[c].fill(0.0);
    }
    int counter = 0;
    for(int s=0; s<t.size(); s++){
      if(counter < int(eval_ind.size())){
        while(time[int(eval_ind[counter])] <= t[s]){
          for(int c=0; c<ncauses; c++){
            if(dN[c][counter] > 0){
              arma::mat Z_minus_Z_bar_A1 = Z_A1[c];
              arma::mat Z_minus_Z_bar_A0 = Z_A0[c];
              Z_minus_Z_bar_A1.each_row() -= Z_bar[c].row(counter);
              Z_minus_Z_bar_A0.each_row() -= Z_bar[c].row(counter);
              if(c == cause-1){
                arma::mat phi_A1_count_j = Z_minus_Z_bar_A1;
                arma::mat phi_A0_count_j = Z_minus_Z_bar_A0;
                phi_A1_count_j.each_col() %= S_A1.col(counter) % dLambda_A1[cause-1].col(counter);
                phi_A0_count_j.each_col() %= S_A0.col(counter) % dLambda_A0[cause-1].col(counter);
                phi_A1_count += sum(repelem(weights_cluster_all_t, 1, Z[c].n_cols) % phi_A1_count_j, 0);
                phi_A0_count += sum(repelem(weights_cluster_all_t, 1, Z[c].n_cols) % phi_A0_count_j, 0);
              }
              arma::mat psi_A1_count_sum2_j = Z_minus_Z_bar_A1;
              arma::mat psi_A0_count_sum2_j = Z_minus_Z_bar_A0;
              psi_A1_count_sum2_j.each_col() %= F_A1.col(counter+1) % dLambda_A1[c].col(counter);
              psi_A0_count_sum2_j.each_col() %= F_A0.col(counter+1) % dLambda_A0[c].col(counter);
              psi_A1_count_sum2[c] += sum(repelem(weights_cluster_all_t, 1, Z[c].n_cols) % psi_A1_count_sum2_j, 0);
              psi_A0_count_sum2[c] += sum(repelem(weights_cluster_all_t, 1, Z[c].n_cols) % psi_A0_count_sum2_j, 0);
            }
          }
          counter++;
          if(counter == int(eval_ind.size())) break;
        }
      }
      std::vector < arma::rowvec > psi_A1_count_sum1(ncauses);
      std::vector < arma::rowvec > psi_A0_count_sum1(ncauses);
      for(int c=0; c<ncauses; c++){
        psi_A1_count_sum1[c].set_size(Z[c].n_cols);
        psi_A1_count_sum1[c].fill(0.0);
        psi_A0_count_sum1[c].set_size(Z[c].n_cols);
        psi_A0_count_sum1[c].fill(0.0);
      }
      if(t[s] >= min(time)){
        arma::uvec eval_ind_t = find((event.elem(nodup) != 0) && (time.elem(nodup) <= t[s]));
        for(int r=0; r<int(eval_ind_t.size()); r++){
          for(int c=0; c<ncauses; c++){
            if(dN[c][r] > 0){
              arma::mat psi_A1_count_sum1_j = Z_A1[c];
              arma::mat psi_A0_count_sum1_j = Z_A0[c];
              psi_A1_count_sum1_j.each_row() -= Z_bar[c].row(r);
              psi_A0_count_sum1_j.each_row() -= Z_bar[c].row(r);
              psi_A1_count_sum1_j.each_col() %= F_A1.col(eval_ind_t.size()) % dLambda_A1[c].col(r);
              psi_A0_count_sum1_j.each_col() %= F_A0.col(eval_ind_t.size()) % dLambda_A0[c].col(r);
              psi_A1_count_sum1[c] += sum(repelem(weights_cluster_all_t, 1, Z[c].n_cols) % psi_A1_count_sum1_j, 0);
              psi_A0_count_sum1[c] += sum(repelem(weights_cluster_all_t, 1, Z[c].n_cols) % psi_A0_count_sum1_j, 0);
            }
          }
        }
      }
      phi_A1.row(s) = phi_A1_count / double(nclusters);
      phi_A0.row(s) = phi_A0_count / double(nclusters);
      for(int c=0; c<ncauses; c++){
        psi_A1[c].row(s) = (psi_A1_count_sum1[c] - psi_A1_count_sum2[c]) / double(nclusters);
        psi_A0[c].row(s) = (psi_A0_count_sum1[c] - psi_A0_count_sum2[c]) / double(nclusters);
      }
    }
    
    // omega__inv * (Z_i - Z_bar(u)) * dN_i(u)
    std::vector< arma::mat > sum34(ncauses);
    for(int c=0; c<ncauses; c++){
      arma::mat Z_minus_Z_bar_dN = Z[c].rows(event_ind) - Z_bar[c];
      Z_minus_Z_bar_dN.each_col() %= dN[c] % weights_cluster;
      sum34[c] = omega_inv[c] * Z_minus_Z_bar_dN.t();
    }
    
    // mean (S(u-) * dLambda_1(u)) & mean ((F_1(t) - F_1(u)) * sum_k dLambda_k(u))
    arma::vec sum1_A1(event_ind.size(), fill::value(0.0));
    arma::vec sum1_A0(event_ind.size(), fill::value(0.0));
    arma::mat sum2_A1(event_ind.size(),t.size(), fill::value(0.0));
    arma::mat sum2_A0(event_ind.size(),t.size(), fill::value(0.0));
    sum1_A1.head(eval_ind.size()) += sum(repelem(weights_cluster_all_t, 1, eval_ind.size()) % S_A1.head_cols(eval_ind.size()) % dLambda_A1[cause-1].head_cols(eval_ind.size()), 0).t();
    sum1_A0.head(eval_ind.size()) += sum(repelem(weights_cluster_all_t, 1, eval_ind.size()) % S_A0.head_cols(eval_ind.size()) % dLambda_A0[cause-1].head_cols(eval_ind.size()), 0).t();
    for(int s=0; s<t.size(); s++){
      if(t[s] >= min(time)){
        arma::uvec eval_ind_t = find((event.elem(nodup) != 0) && (time.elem(nodup) <= t[s]));
        arma::mat dLambda_A1_all(nodup.size(), eval_ind_t.size());
        arma::mat dLambda_A0_all(nodup.size(), eval_ind_t.size());
        for(int c=0; c<ncauses; c++){
          dLambda_A1_all += dLambda_A1[c].head_cols(eval_ind_t.size());
          dLambda_A0_all += dLambda_A0[c].head_cols(eval_ind_t.size());
        }
        if(eval_ind_t.size() > 0){
          sum2_A1.submat(0,s,eval_ind_t.size()-1,s) += sum(repelem(weights_cluster_all_t, 1, eval_ind_t.size()) % (repelem(F_A1.col(eval_ind_t.size()), 1, eval_ind_t.size()) - F_A1.cols(1, eval_ind_t.size())) % dLambda_A1_all, 0).t();
          sum2_A0.submat(0,s,eval_ind_t.size()-1,s) += sum(repelem(weights_cluster_all_t, 1, eval_ind_t.size()) % (repelem(F_A0.col(eval_ind_t.size()), 1, eval_ind_t.size()) - F_A0.cols(1, eval_ind_t.size())) % dLambda_A0_all, 0).t();
        }
      }
    }
    
    // U_n_hat
    arma::mat res_WBS_A1(bs_iter, t.size());
    arma::mat res_WBS_A0(bs_iter, t.size());
    SD_WBS.fill(0.0);
    for(int s=0; s<t.size(); s++){
      arma::vec t_ind = zeros(event_ind.size());
      if(t[s] >= min(time.elem(eval_ind))){
        int index_t = max(find(time.elem(eval_ind) <= t[s]));
        t_ind.head_rows(index_t+1) = 1*ones(index_t+1);
      }
      arma::vec sum3_A1 = (phi_A1.row(s)*sum34[cause-1]).t();
      arma::vec sum3_A0 = (phi_A0.row(s)*sum34[cause-1]).t();
      arma::vec sum4_A1(event_ind.size(), fill::value(0.0));
      arma::vec sum4_A0(event_ind.size(), fill::value(0.0));
      for(int c=0; c<ncauses; c++){
        sum4_A1 += (psi_A1[c].row(s) * sum34[c]).t();
        sum4_A0 += (psi_A0[c].row(s) * sum34[c]).t();
      }
      for(int i=0; i<bs_iter; i++){
        res_WBS_A1(i,s) = sum(G_WBS.col(i) % (t_ind%(sum1_A1-sum2_A1.col(s))+sum3_A1-sum4_A1)) / sqrt(nclusters);
        res_WBS_A0(i,s) = sum(G_WBS.col(i) % (t_ind%(sum1_A0-sum2_A0.col(s))+sum3_A0-sum4_A0)) / sqrt(nclusters);
      }
      SD_WBS[s] = stddev(res_WBS_A1.col(s) - res_WBS_A0.col(s));
    }
    
    // Un
    arma::uvec eval_ind_new = find(SD_WBS > 0);
    Un_std_WBS = abs(res_WBS_A1.cols(eval_ind_new) - res_WBS_A0.cols(eval_ind_new)) / repelem(SD_WBS.elem(eval_ind_new).t(), bs_iter, 1);
    
    clock.tick("WBS_CI_CB");
    if(WBS_CI_CB){
      // CIs
      CI_WBS.set_size(2, t.size());
      CI_WBS.fill(0.0);
      for(int s=0; s<int(t.size()); s++){
        if(t[s] >= min(time)){
          double q_WBS = arma::vec(sort(abs(res_WBS_A1.col(s) - res_WBS_A0.col(s))))[round(bs_iter * level)];
          CI_WBS(0,s) = max(F_A1_mean[s] - F_A0_mean[s] - q_WBS / sqrt(nclusters), -1.0);
          CI_WBS(1,s) = min(F_A1_mean[s] - F_A0_mean[s] + q_WBS / sqrt(nclusters), 1.0);
        }
      }
      // CBs
      CB_WBS.set_size(2, t.size());
      CB_WBS.fill(0.0);
      double q_WBS = arma::vec(sort(max(Un_std_WBS, 1)))[round(bs_iter * level)];
      CB_WBS.submat(0,eval_ind_new[0],0,t.size()-1) = max(F_A1_mean.elem(eval_ind_new) - F_A0_mean.elem(eval_ind_new) - q_WBS * SD_WBS.elem(eval_ind_new) / sqrt(nclusters), -1.0*ones(eval_ind_new.size())).t();
      CB_WBS.submat(1,eval_ind_new[0],1,t.size()-1) = min(F_A1_mean.elem(eval_ind_new) - F_A0_mean.elem(eval_ind_new) + q_WBS * SD_WBS.elem(eval_ind_new) / sqrt(nclusters), ones(eval_ind_new.size())).t();
    }
    clock.tock("WBS_CI_CB");
    
  }
  
  clock.tock("WBS");
  
  clock.stop("clock");
  
  List res = List::create(Named("ATE") = F_A1_mean - F_A0_mean,
                          Named("SE_IF") = SE_IF, 
                          Named("Un_std_IF") = Un_std_IF,
                          Named("CI_IF") = CI_IF,
                          Named("CB_IF") = CB_IF,
                          Named("SE_WBS") = SD_WBS.t() / sqrt(nclusters),
                          Named("Un_std_WBS") = Un_std_WBS,
                          Named("CI_WBS") = CI_WBS,
                          Named("CB_WBS") = CB_WBS);
  
  return(res);
  
  
}
